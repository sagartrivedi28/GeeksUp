<div class="copy">
    <p> &copy; {{ $year }} All Rights Reserved.</p>
</div>