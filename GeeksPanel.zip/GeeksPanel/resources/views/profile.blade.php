
<!--
Author: W3layouts
Author URL: http://w3layouts.com
License: Creative Commons Attribution 3.0 Unported
License URL: http://creativecommons.org/licenses/by/3.0/
-->
<!DOCTYPE HTML>
<html>
<head>
<title>GeeksUP</title>
<meta name="viewport" content="width=device-width, initial-scale=1">
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<meta name="keywords" content="Minimal Responsive web template, Bootstrap Web Templates, Flat Web Templates, Android Compatible web template, 
Smartphone Compatible web template, free webdesigns for Nokia, Samsung, LG, SonyEricsson, Motorola web design" />
<script type="application/x-javascript"> addEventListener("load", function() { setTimeout(hideURLbar, 0); }, false); function hideURLbar(){ window.scrollTo(0,1); } </script>
<link href="css/bootstrap.min.css" rel='stylesheet' type='text/css' />
<!-- Custom Theme files -->
<link href="css/style.css" rel='stylesheet' type='text/css' />
<link href="css/font-awesome.css" rel="stylesheet"> 
<script src="js/jquery.min.js"> </script>
<!-- Mainly scripts -->
<script src="js/jquery.metisMenu.js"></script>
<script src="js/jquery.slimscroll.min.js"></script>
<!-- Custom and plugin javascript -->
<link href="css/custom.css" rel="stylesheet">
<script src="js/custom.js"></script>
<script src="js/screenfull.js"></script>
		<script>
		$(function () {
			$('#supported').text('Supported/allowed: ' + !!screenfull.enabled);

			if (!screenfull.enabled) {
				return false;
			}
			$('#toggle').click(function () {
				screenfull.toggle($('#container')[0]);
			});
		});
		</script>

<!--skycons-icons-->
<script src="js/skycons.js"></script>
<!--//skycons-icons-->
</head>
<body>
<div id="wrapper">

<!---->
        <nav class="navbar-default navbar-static-top" role="navigation">
            @include('layout.topbar_menu')
	  
		    @include('layout.sidebar_menu')
        </nav>
        <div id="page-wrapper" class="gray-bg dashbard-1">
       <div class="content-main">
 
  		<!--banner-->	
		    <div class="banner">	   
				<h2>
				<a href="index.html">Home</a>
				<i class="fa fa-angle-right"></i>
				<span>Profile</span>
				</h2>
		    </div>
		<!--//banner-->
		<div class="content-main">
			<div class="col-md-9">
				<div class="profile-bottom">
				<h3><i class="fa fa-user"></i>Profile</h3>
				<div class="profile-bottom-top">
				<div class="col-md-4 profile-bottom-img">
					<img src="images/pr.jpg" alt="">
				</div>
				<div class="col-md-8 profile-text">
					<h6>Jack Dorsey</h6>
					<table>
						<tr>
							<td>Email</td>
							<td> :</td>
							<td><a href="info@gmail.com">info@lorem.com</a></td>
						</tr>
						<tr>
							<td>Skills</td>
							<td> :</td>
							<td> HTML, CSS,Jqury, Bootstrap</td>
						</tr>
						<tr>
							<td>Area of Interest</td>
							<td> :</td>
							<td> Information technology,Web Development,Web Design</td>
						</tr>
						<tr>
							<td>Accomplishments </td>
							<td>:</td>
							<td> viratgandhi.com</td>
						</tr>
						<tr>
							<td>Certificates </td>
							<td>:</td>
							<td> Bachelor of Engineering</td>
						</tr>
						<tr>
							<td>Paper Published </td>
							<td>:</td>
							<td>-</td>
						</tr>
						<tr>
							<td>Courses </td>
							<td>:</td>
							<td> Laravel, CodeIgniter, Planning</td>
						</tr>
					</table>
				</div>
				<div class="clearfix"></div>
				</div>
				<hr/>
				<h3>About</h3>
				<div class="row">
					<div class="col-md-offset-1 col-md-10 text-justify">Lorem ipsum dolor sit amet, consectetur adipiscing elit. Morbi aliquet ex eget justo viverra lobortis. Duis nec enim quis elit auctor aliquam. In maximus vestibulum mauris eu tristique. Ut nec dictum quam. Duis finibus fringilla arcu, porta varius tellus. Proin velit nulla, pretium nec diam at, tincidunt viverra urna. Morbi sodales elit quis magna tempor egestas. Duis sed risus quam. Nam aliquam purus malesuada aliquam aliquet. Integer bibendum faucibus nisi sed efficitur. Etiam nisi ligula, porta sit amet sagittis at, auctor id diam. Donec velit metus, dignissim tempus suscipit nec, efficitur ullamcorper leo. Praesent non enim vel dolor blandit venenatis ut sit amet mi.</div>
					<div class="col-md-offset-1"></div>
				</div>
				<!--<hr/>
				 <div class="profile-bottom-bottom">
				<div class="col-md-6 profile-fo">
					<h4>23,5k</h4>
					<p>Followers</p>
					<a href="#" class="pro"><i class="fa fa-plus-circle"></i>Follow</a>
				</div>
				<div class="col-md-6 profile-fo">
					<h4>348</h4>
					<p>Following</p>
					<a href="#" class="pro1"><i class="fa fa-user"></i>View Profile</a>
				</div>
				<div class="clearfix"></div>
				</div> -->
				<div class="profile-btn">
					<button type="button" href="#" class="btn bg-red">Save changes</button>
	           		<div class="clearfix"></div>
				</div>
			</div>	
			</div>
			
			<div class="col-md-3">
				<div class="right-bar">
					<div class="row">
						<a><i class="fa fa-file-pdf-o"> Export CV</i></a>
					</div>
					<div class="row">
						<a><i class="fa fa-male"> About Me</i></a>
					</div>
					<div class="row">
						<a><i class="fa fa-users">13 Followers</i></a>
					</div>
					<div class="row">
						<a><i class="fa fa-user">13 Following</i></a>
					</div>
				</div>
				
			</div>
		<!--content-->
		<div class="content-top">			
			
		<div class="clearfix"> </div>
		</div>
		<!---->
		<br/><br/><br/><br/><br/><br/><br/><br/><br/><br/>	
		<!--//content-->
		@include('layout.footer')
		</div>
		<div class="clearfix"> </div>
       </div>
     </div>
<!---->
<!--scrolling js-->
	<script src="js/jquery.nicescroll.js"></script>
	<script src="js/scripts.js"></script>
	<!--//scrolling js-->
	<script src="js/bootstrap.min.js"> </script>
</body>
</html>