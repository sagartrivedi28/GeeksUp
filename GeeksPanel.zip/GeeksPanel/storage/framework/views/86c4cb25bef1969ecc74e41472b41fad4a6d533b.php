<div class="copy">
    <p> &copy; <?php echo e($year); ?> All Rights Reserved.</p>
</div>